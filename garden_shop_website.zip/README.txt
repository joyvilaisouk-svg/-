ວິທີໃຊ້ແລະອັບໂຫຼດເຄື່ອງໄຟລ໌ເຂົ້າ GitHub Pages
================================================================================

ຟາຍນີ້ປະກອບໄປດ້ວຍ:
- index.html (ແລະ CSS ຢູ່ໃນຫນ້າດຽວ)
- assets/ (ພາບ placeholder: logo, garden, hoe, watering, soil, spray, gloves)

ຂັ້ນຕອນອັບໂຫຼດເບີງ GitHub Pages (ວິທີງ່າຍ):
1. ສ້າງ GitHub account ຖ້າຍັງບໍ່ມີ.
2. ສ້າງ repository ໃໝ່ (public) ຊື່ເຊັ່ນ `garden-shop`.
3. ອັບໂຫຼດໄຟລ໌ທັງໝົດເຂົ້າໄປໃນ repository (index.html ແລະ assets/).
4. ໄປທີ່ Settings → Pages → ເລືອກ branch `main` ແລະ folder `/ (root)`.
5. ລໍຖ້າ GitHub ຊ່ວງສັ້ນ (1-2 ນາທີ) ແລ້ວທ່ານຈະໄດ້ລິ້ງເວັບ ຊ່ວງເວລາຈໍາເລີຍ.

ການອັບໂຫຼດໂດຍ Git (option - ກ້ອນທີ):
1. ທຳ git init ໃນໂຟນເດີ້
2. git add .
3. git commit -m "Initial site"
4. git branch -M main
5. git remote add origin https://github.com/USERNAME/REPO.git
6. git push -u origin main

ຫາກຕ້ອງການຊ່ວຍອັບ files ຫຼື ຊ່ວຍກວດ code ພວກເຮົາຍິນດີຊ່ວຍ!
